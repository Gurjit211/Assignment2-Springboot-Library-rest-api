package com.assignment2.assignment2_rest_gurjitsinghsidhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2RestGurjitSinghSidhuApplicationTests {

    @Test
    void contextLoads() {
    }

}
