package com.assignment2.assignment2_rest_gurjitsinghsidhu.repository;

import com.assignment2.assignment2_rest_gurjitsinghsidhu.model.Publisher;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublisherRepository extends JpaRepository<Publisher, Long> {
}
