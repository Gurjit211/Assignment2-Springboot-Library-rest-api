package com.assignment2.assignment2_rest_gurjitsinghsidhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2RestGurjitSinghSidhuApplication {

    public static void main(String[] args) {
        SpringApplication.run(Assignment2RestGurjitSinghSidhuApplication.class, args);
    }

}
