package com.assignment2.assignment2_rest_gurjitsinghsidhu.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "members")
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private String email;

    // Date the person joined the library
    private LocalDate membershipDate;

    /* ---------- Constructors ---------- */
    public Member() { }

    public Member(String firstName,
                  String lastName,
                  String email,
                  LocalDate membershipDate) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.email     = email;
        this.membershipDate = membershipDate;
    }

    /* ---------- Getters & Setters ---------- */
    public Long getId()                         { return id; }
    public void setId(Long id)                  { this.id = id; }

    public String getFirstName()                { return firstName; }
    public void setFirstName(String firstName)  { this.firstName = firstName; }

    public String getLastName()                 { return lastName; }
    public void setLastName(String lastName)    { this.lastName = lastName; }

    public String getEmail()                    { return email; }
    public void setEmail(String email)          { this.email = email; }

    public LocalDate getMembershipDate()        { return membershipDate; }
    public void setMembershipDate(LocalDate membershipDate) {
        this.membershipDate = membershipDate;
    }
}
