package com.assignment2.assignment2_rest_gurjitsinghsidhu.controller;

import com.assignment2.assignment2_rest_gurjitsinghsidhu.model.Books;
import com.assignment2.assignment2_rest_gurjitsinghsidhu.repository.BooksRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")   //  →  http://localhost:8080/books
public class BooksController {

    @Autowired
    private BooksRepository booksRepository;

    /* ---------- CREATE ---------- */
    @PostMapping
    public Books addBook(@RequestBody Books book) {
        return booksRepository.save(book);
    }

    /* ---------- READ ALL ---------- */
    @GetMapping
    public List<Books> getAllBooks() {
        return booksRepository.findAll();
    }

    /* ---------- READ BY ID ---------- */
    @GetMapping("/{id}")
    public ResponseEntity<Books> getBook(@PathVariable Long id) {
        return booksRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
