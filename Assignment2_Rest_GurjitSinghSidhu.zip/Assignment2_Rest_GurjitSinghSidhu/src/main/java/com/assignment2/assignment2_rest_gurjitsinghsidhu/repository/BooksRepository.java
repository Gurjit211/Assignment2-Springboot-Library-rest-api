package com.assignment2.assignment2_rest_gurjitsinghsidhu.repository;

import com.assignment2.assignment2_rest_gurjitsinghsidhu.model.Books;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BooksRepository extends JpaRepository<Books, Long> {
    // No code needed. Spring will auto-implement common methods. # Thats good with Spring
}
