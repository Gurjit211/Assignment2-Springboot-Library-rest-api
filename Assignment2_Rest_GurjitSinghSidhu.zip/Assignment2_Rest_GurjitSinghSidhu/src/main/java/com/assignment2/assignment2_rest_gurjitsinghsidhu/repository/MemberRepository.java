package com.assignment2.assignment2_rest_gurjitsinghsidhu.repository;

import com.assignment2.assignment2_rest_gurjitsinghsidhu.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepository extends JpaRepository<Member, Long> {
}
