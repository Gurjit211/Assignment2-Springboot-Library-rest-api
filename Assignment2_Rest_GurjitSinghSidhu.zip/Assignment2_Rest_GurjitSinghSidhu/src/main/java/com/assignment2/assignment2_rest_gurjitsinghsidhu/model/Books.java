// Books.java
package com.assignment2.assignment2_rest_gurjitsinghsidhu.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@Table(name = "books")
public class Books {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String isbn;
    private int pages;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "publisher_id")
    @JsonBackReference           // prevents infinite recursion when returning JSON
    private Publisher publisher;

    /* ---------- Constructors ---------- */
    public Books() { }

    public Books(String title, String isbn, int pages, Publisher publisher) {
        this.title = title;
        this.isbn = isbn;
        this.pages = pages;
        this.publisher = publisher;
    }

    /* ---------- Getters & Setters ---------- */
    public Long getId()               { return id; }
    public void setId(Long id)        { this.id = id; }

    public String getTitle()          { return title; }
    public void setTitle(String title){ this.title = title; }

    public String getIsbn()           { return isbn; }
    public void setIsbn(String isbn)  { this.isbn = isbn; }

    public int getPages()             { return pages; }
    public void setPages(int pages)   { this.pages = pages; }

    public Publisher getPublisher()   { return publisher; }
    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }
}
