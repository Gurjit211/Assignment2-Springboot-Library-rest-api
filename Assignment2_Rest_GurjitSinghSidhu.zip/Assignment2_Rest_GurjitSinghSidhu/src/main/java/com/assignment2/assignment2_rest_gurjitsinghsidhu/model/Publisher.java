// Publisher.java
package com.assignment2.assignment2_rest_gurjitsinghsidhu.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "publishers")
public class Publisher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String address;

    @OneToMany(
            mappedBy = "publisher",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JsonManagedReference         // pairs with @JsonBackReference
    private List<Books> books;

    /* ---------- Constructors ---------- */
    public Publisher() { }

    public Publisher(String name, String address) {
        this.name = name;
        this.address = address;
    }

    /* ---------- Getters & Setters ---------- */
    public Long getId()                { return id; }
    public void setId(Long id)         { this.id = id; }

    public String getName()            { return name; }
    public void setName(String name)   { this.name = name; }

    public String getAddress()         { return address; }
    public void setAddress(String address) { this.address = address; }

    public List<Books> getBooks()      { return books; }
    public void setBooks(List<Books> books) { this.books = books; }
}
