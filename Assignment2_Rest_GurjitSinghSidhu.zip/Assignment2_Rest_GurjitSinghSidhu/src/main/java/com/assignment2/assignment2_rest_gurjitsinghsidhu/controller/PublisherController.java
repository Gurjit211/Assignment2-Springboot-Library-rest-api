package com.assignment2.assignment2_rest_gurjitsinghsidhu.controller;

import com.assignment2.assignment2_rest_gurjitsinghsidhu.model.Publisher;
import com.assignment2.assignment2_rest_gurjitsinghsidhu.repository.PublisherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/publishers")
public class PublisherController {

    @Autowired
    private PublisherRepository publisherRepository;

    @PostMapping
    public Publisher createPublisher(@RequestBody Publisher publisher) {
        return publisherRepository.save(publisher);
    }

    @GetMapping
    public List<Publisher> getAllPublishers() {
        return publisherRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Publisher> getPublisherById(@PathVariable Long id) {
        return publisherRepository.findById(id);
    }
}
